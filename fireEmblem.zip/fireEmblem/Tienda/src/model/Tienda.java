package model;

import java.util.ArrayList;
import java.util.Scanner;


public class Tienda {
	private ArrayList <String> listaTienda = new ArrayList<>();

	public Tienda() {
		
	}
	public void añadirObjetosTienda() {
		listaTienda.add("Trigo");
		listaTienda.add("Dildo");
		listaTienda.add("Hacha");
	}
	public  void imprimirTienda() {
		System.out.println(listaTienda.toString());
	}
	public void menuTienda(Personaje personaje) {
		Scanner sc = new Scanner(System.in);
		añadirObjetosTienda();
		imprimirTienda();
		System.out.println("Que objetos quieres comprar");
		int opcion = sc.nextInt();
		System.out.println(" El objeto elegido fue:" + listaTienda.get(opcion - 1));
		personaje.añadirObjeto(listaTienda.get( opcion -1));
		
	}

}
