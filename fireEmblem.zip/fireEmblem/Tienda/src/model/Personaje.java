package model;

import java.util.ArrayList;

public class Personaje {
	public ArrayList <String> inventario = new ArrayList<>();
	
	

	public Personaje() {
		
	}
	public void añadirObjeto (String objeto) {
		inventario.add(objeto);
		System.out.println(inventario.toString());
	}
}
