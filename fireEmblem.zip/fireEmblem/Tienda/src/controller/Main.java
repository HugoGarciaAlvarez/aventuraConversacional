package controller;
import model.*;
public class Main {

	public static void main(String[] args) {
		Tienda tienda = new Tienda();
		Personaje personaje = new Personaje();
		tienda.menuTienda(personaje);
	}

}
