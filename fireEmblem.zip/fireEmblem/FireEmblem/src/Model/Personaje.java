package Model;

import java.util.ArrayList;
import java.util.Random;

public abstract class Personaje {

	private String nombre;
	private int vida;
	private int ataque;
	private int defensa;

	public Personaje(String nombre, int vida, int ataque, int defensa) {
		this.nombre = nombre;
		this.vida = vida;
		this.ataque = ataque;
		this.defensa = defensa;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getAtaque() {
		return ataque;
	}

	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}

	public int getDefensa() {
		return defensa;
	}

	public void setDefensa(int defensa) {
		this.defensa = defensa;
	}

	public Personaje atacar(Personaje hijo, int ataques) {
		int contador = 0;
		int totalDefensa = hijo.getDefensa();
		System.out.println();
		System.out.println("##COMIENZO DEL TURNO DE " + nombre + " ##");
		System.out.println();
		while (contador != ataques) {
			if (hijo.getDefensa() > 0) {
				hijo.setDefensa(hijo.getDefensa() - ataque);

				
				if (hijo.getDefensa() < 0) {
					totalDefensa = totalDefensa - getDefensa();
					hijo.setDefensa(0);
					System.out.println("Le rompiste el escudo (" + ataque + ")");
					System.out.println("El arma traspasa el escudo, quitandole " + totalDefensa + " puntos de vida");
					hijo.setVida(hijo.getVida() - totalDefensa);
				}
			} else {
				System.out.println("Atacas con el arma");
				System.out.println("'Sonido de espada' le quitas " + ataque);
				hijo.setVida(hijo.getVida() - ataque);
			
			}
			if(hijo.getVida() <0) {
				hijo.setVida(0);
			}
			contador ++;
		}
		
		
		System.out.println("##FIN DEL TURNO DE " + nombre + " ##");

		return hijo;
	}

	public static void combate(Random random, ArrayList<Enemigo> enemigos, Enemigo enemigo, Jugador jugador,
			Destreza destreza) {
		enemigo = enemigo.elegirAleatoriamenteEnemigo(random, enemigos, enemigo);
		boolean verdadero = false;
		while (jugador.getNivel() != 10 && !verdadero) {
			jugador.atacar(enemigo, 3);
			enemigo.atacar(jugador, 1);
			System.out.println("Le quedan a " + jugador.getNombre() + " " + jugador.getVida() + " puntos de vida ");
			System.out.println("Le quedan a " + enemigo.getNombre() + " " + enemigo.getVida() + " puntos de vida ");
			if (enemigo.getVida() == 0) {
				enemigo.resucitar(enemigo);
				jugador.subirDeNivel(jugador, enemigo, destreza);
				enemigo = enemigo.elegirAleatoriamenteEnemigo(random, enemigos, enemigo);
			}else if (jugador.getVida() == 0) {
				verdadero =true;
			}
		}
		if (jugador.getNivel() == 10) {
			System.out.println("Enorabuena, subiste a nivel 10");
		} else {
			System.out.println("Has caido derrotado");
		}
		System.out.println("##FIN DEL PROGRAMA##");

	}

}
