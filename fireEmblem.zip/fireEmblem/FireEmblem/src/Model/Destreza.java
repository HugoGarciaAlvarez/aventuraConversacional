package Model;

public enum Destreza {
	FUERTE(50,10,4), DEBIL(30,8,2);
	
	private final int VIDA;
	private final int ATAQUE;
	private final int DEFENSA;
	private Destreza(int VIDA, int ATAQUE, int DEFENSA) {
		this.VIDA = VIDA;
		this.ATAQUE = ATAQUE;
		this.DEFENSA = DEFENSA;
	}
	public int getVIDA() {
		return VIDA;
	}
	public int getATAQUE() {
		return ATAQUE;
	}
	public int getDEFENSA() {
		return DEFENSA;
	}
	
	
	
	
	
	

}
