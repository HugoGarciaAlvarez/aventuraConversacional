package Model;

import java.util.Random;
import java.util.Scanner;

public class Jugador extends Personaje {
	private Casa casa;
	private int vidaInicial;
	private int nivel;

	public Jugador(String nombre, Casa casa, int nivel) {
		super(nombre, 0, 0, 0);
		this.nivel = nivel;
		this.setCasa(casa);
		this.vidaInicial = getVida();
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public Casa getCasa() {
		return casa;
	}

	public void setCasa(Casa casa) {
		this.casa = casa;
	}

	public Jugador elegirPersonaje(Scanner sc, Jugador jugador) {
		boolean acertado = false;
		System.out.println("Elige uno de estos tres personajes");
		System.out.println("Jugador 1, Casa 1" + "\nJugador 2, Casa 2" + "\nJugador 3, Casa 3");
		int opcion = sc.nextInt();
		if (opcion == 1 || opcion == 2 || opcion == 3) {
			System.out.println("Bien introducido");
			acertado = true;
		}
		while (acertado != true) {
			System.out.println("Mal introducido");
			System.out.println("Elige un numero entre 1 a 3");
			opcion = sc.nextInt();
			if (opcion == 1 || opcion == 2 || opcion == 3) {
				System.out.println("Bien introducido");
				acertado = true;
			}
		}
		System.out.println("Eligiendo personaje seleccionado");
		if (opcion == 1) {
			setNombre("Personaje 1");
			setCasa(Casa.CASA1);
		} else if (opcion == 2) {
			setNombre("Personaje 2");
			setCasa(Casa.CASA2);
		} else {
			setNombre("Personaje 3");
			setCasa(Casa.CASA3);
		}

		return jugador;
	}

	public Jugador valoresAleatoriosPersonaje(Random random, Jugador jugador) {

		int vida = random.nextInt(60 - 40 + 1) + 40;
		int ataque = random.nextInt(12 - 7 + 1) + 7;
		int defensa = random.nextInt(7 - 4 + 1) + 4;
		setVida(vida);
		setAtaque(ataque);
		setDefensa(defensa);

		return jugador;
	}

	public Jugador subirDeNivel(Jugador jugador, Enemigo enemigo, Destreza destreza) {
		
		if(enemigo.getDestreza() == Destreza.DEBIL) {
			setNivel(getNivel()+1);
			setVida(getVida()+5);
			setAtaque(getAtaque()+2);
			setDefensa(getDefensa()+1);
		}else {
			setNivel(getNivel()+2);
			setVida(getVida()+8);
			setAtaque(getAtaque()+3);
			setDefensa(getDefensa()+2);
		}
		setVida(getVida()+10);
		if(getVida()> vidaInicial) {
			
			setVida(vidaInicial);
		}
		
		
		
		System.out.println("Subiste a nivel " + getNivel()+" y recupersate 10 puntos de vida");
		return jugador;

	}

	public void imprimirPersonaje() {
		System.out.println("Nombre =" + getNombre() + " \nvida = " + getVida() + ", \nataque =" + getAtaque()
				+ ", \ndefensa = " + getDefensa() + "\n casa " + getCasa() + ", \nnivel " + getNivel());
	}

	@Override
	public String toString() {
		return "Jugador [casa=" + casa + ", nivel=" + nivel + ", getNombre()=" + getNombre() + ", getVida()="
				+ getVida() + ", getAtaque()=" + getAtaque() + ", getDefensa()=" + getDefensa() + "]";
	}

}
