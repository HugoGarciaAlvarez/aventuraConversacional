package Model;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Enemigo extends Personaje {

	private Destreza destreza;

	public Enemigo(String nombre, Destreza destreza) {
		super(nombre, 0, 0, 0);

		this.destreza = destreza;
		setVida(destreza.getVIDA());
		setAtaque(destreza.getATAQUE());
		setDefensa(destreza.getDEFENSA());

	}

	public Destreza getDestreza() {
		return destreza;
	}

	public void setDestreza(Destreza destreza) {
		this.destreza = destreza;
	}

	public void imprimirPersonaje() {
		System.out.println("Nombre =" + getNombre() + ", \nvida = " + getVida() + ", \nataque =" + getAtaque()
				+ ", \ndefensa = " + getDefensa() + ", \ndestreza = " + destreza);
	}

	public ArrayList<Enemigo> enemigosEnfrentados(Scanner sc, ArrayList<Enemigo> enemigos) {

		System.out.println("Contra cuantos enemigos te quieres enfrentar, de 2 a 5");
		int opcion = sc.nextInt();
		while (opcion != 2 && opcion != 3 && opcion != 4 && opcion != 5) {
			System.out.println("numero mal introducido, de 2 a 5");
			opcion = sc.nextInt();
		}
		opcion--;
		/* i = 0 1 2 3 4 */
		int i = 4;

		while (i != opcion) {
			enemigos.remove(i);
			i--;

		}
		System.out.println();
		return enemigos;
	}

	public Enemigo elegirAleatoriamenteEnemigo(Random random, ArrayList<Enemigo> enemigos, Enemigo enemigo) {
		int Ialeatorio = random.nextInt(enemigos.size());
		enemigo = enemigos.get(Ialeatorio);
		return enemigo;

	}

	public Enemigo resucitar(Enemigo enemigo) {
		setVida(destreza.getVIDA());
		setAtaque(destreza.getATAQUE() + 1);
		setDefensa(destreza.getDEFENSA() + 1);

		return enemigo;

	}

	@Override
	public String toString() {
		return "Enemigo [destreza=" + destreza + ", getNombre=" + getNombre() + ", getVida=" + getVida()
				+ ", getAtaque=" + getAtaque() + ", getDefensa=" + getDefensa() + "] \n";
	}

}
