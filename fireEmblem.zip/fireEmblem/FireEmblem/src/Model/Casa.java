package Model;

public enum Casa {
	CASA1,
	CASA2,
	CASA3
}
