package Controller;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import Model.*;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Random random = new Random();
		// Meterse a los metodos de las clases//
		Jugador jugador = new Jugador("", Casa.CASA1, 1);
		Enemigo enemigo = new Enemigo("", Destreza.DEBIL);
		// Array List de enemigos//

		ArrayList<Enemigo> enemigos = new ArrayList<Enemigo>();

		enemigos.add(new Enemigo("Enemigo 1", Destreza.DEBIL));
		enemigos.add(new Enemigo("Enemigo 2", Destreza.DEBIL));
		enemigos.add(new Enemigo("Enemigo 3", Destreza.DEBIL));
		enemigos.add(new Enemigo("Enemigo 4", Destreza.FUERTE));
		enemigos.add(new Enemigo("Enemigo 5", Destreza.FUERTE));
		// Fin Array List de enemigos//

		/* Comienzo del programa */
		jugador =jugador.elegirPersonaje(sc, jugador);
		jugador =jugador.valoresAleatoriosPersonaje(random, jugador);
		enemigos = enemigo.enemigosEnfrentados(sc, enemigos);
		Personaje.combate(random, enemigos, enemigo, jugador, enemigo.getDestreza());
		
	}
	
		

}
